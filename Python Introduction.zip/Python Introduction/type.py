name = 'bob'
age = 44
weight = 105.5

print(type(name))
print(type(age))
print(type(weight))

print(name.upper())
print(name.title())