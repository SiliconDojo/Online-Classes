from random import randint
import time

number = randint(0,10)
print(number)
time.sleep(2)

number = randint(0,10)
print(number)
time.sleep(2)

number = randint(0,10)
print(number)